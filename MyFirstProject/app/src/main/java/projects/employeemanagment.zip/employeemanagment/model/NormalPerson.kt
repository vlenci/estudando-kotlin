package projects.employeemanagment.model

open class NormalPerson {

    fun walk() {
        println("I'm walking...")
    }

    fun drinkingWater() {
        println("I'm drinking water...")
    }
}